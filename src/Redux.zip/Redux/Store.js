import AuthReducer from './Reducers/AuthReducer'
 import { combineReducers, createStore,applyMiddleware } from 'redux'
 import firebase from 'firebase';
 import createSagaMiddleware from 'redux-saga'
import  authSaga from './Sagas/AuthSaga'

 var config = {
    apiKey: "AIzaSyBOGl6AEoPnipZGqKsUOC2DMAtNxNk6yWo",
    authDomain: "auth-d46c9.firebaseapp.com",
    databaseURL: "https://auth-d46c9.firebaseio.com",
    projectId: "auth-d46c9",
    storageBucket: "auth-d46c9.appspot.com",
    messagingSenderId: "712084747960"
  };
  firebase.initializeApp(config);

  const sagaMiddleware = createSagaMiddleware()

 const rootReducer = combineReducers({
    Auth: AuthReducer
 })

  const Store = createStore(rootReducer, applyMiddleware(sagaMiddleware))
  sagaMiddleware.run( authSaga)
 export default Store

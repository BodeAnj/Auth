import authSaga from './AuthSaga'


const rootSaga = function* rootSaga() {
    yield [
        authSaga()
    ]
}

export default rootSaga;
import { call,put,takeEvery,apply } from 'redux-saga/effects'
import {
    SIGNUP_USER_SUCCESS,
    SIGNUP_USER_FAIL,
    SIGNUP_USER_REQUESTING
} from '../Actions/Types'
import firebase from 'firebase'

export function* watchAsyncSignUp({ email,password }) {
    console.log(email, password, '+++++++++++++++++++++SAGA')
   try {
      const data = yield apply(firebase.auth().createUserWithEmailAndPassword(email, password))
      yield put({type:SIGNUP_USER_SUCCESS , data})
   } catch (error) {
    
    yield put({type:SIGNUP_USER_FAIL , error})
   }
}

export default function* authSaga() {
    yield takeEvery(SIGNUP_USER_REQUESTING, watchAsyncSignUp)
  }
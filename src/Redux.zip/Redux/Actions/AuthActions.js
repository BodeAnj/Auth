import { 
    SIGNUP_USER_REQUESTING
} from './Types'





export const signUpRequesting = ({ email,password }) => {
    console.log(email, password, '>>>>>>>>>>>>>>>>ACTIONS')
    return{
    type: SIGNUP_USER_REQUESTING,
    email,
    password 
    }
}

import {
    SIGNUP_USER_SUCCESS,
    SIGNUP_USER_FAIL
} from '../Actions/Types'   


const INITIAL_STATE = { 
    email : null,
    password: null
}

export default (state = INITIAL_STATE,action) => {
    console.log(action, '++++++++++++++++REDUXCER')
    switch(action.type) {
        case SIGNUP_USER_SUCCESS:
        return { status: 'success' }
        // case SIGNUP_USER_FAIL: 
        // return { status :'fail' }
        default :
            return state
    }

}